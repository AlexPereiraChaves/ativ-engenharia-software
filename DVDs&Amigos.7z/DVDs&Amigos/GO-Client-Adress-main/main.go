package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strings"
)

type Amigo struct {
	Id		string 		`json:"id"`
	Nome 	string 		`json:"nome"`
	Telefone 	string 		`json:"telefone"`
	Email 	string 		`json:"email"`
	Endereco 		string 	`json:"enderecos"`
	DataEmprestimo Emprestimo `json:"emprestimo"`
}

type Dvd struct {
	Id 			string 	`json:"endereco_id"`
	titulo string `json:"titulo"`
	Sinopse        string    `json:"sinopse"`
	Diretor     string `json:"diretor"`
	Ator 		string 	`json:"ator"`
	Genero 		string 	`json:"genero"`
	FaixaEt 	FaixaEtaria 	`json:"faixa"`
}

type FaixaEtaria struct {
	De 	int 	`json:"de"`
	Ate 	int 	`json:"ate"`
}

type Emprestimo struct {
	DataEmp 	string 	`json:"dataemp"`
	DataDev 	string 	`json:"datadev"`
}

// var pessoas []Pessoa

func main() {
	getInformationsJSON()

	http.HandleFunc("/new-dvd/", getAllPessoas)

	http.HandleFunc("/new-amigo/", buscarPessoaPorCidade)

	http.HandleFunc("/new-emprestimo/", buscarPessoaPorCidade)

	http.HandleFunc("/all-emprestimos", getAllEmprestimos)

	log.Fatal(http.ListenAndServe(":8081", nil))
}

func pingHandler(w http.ResponseWriter, r *http.Request) {
	_, err := fmt.Fprintf(w, "ping")

	if err != nil {
		log.Fatal(err)
	}
}

func readPessoasFromArchive() []byte {
	byteValueJSON, err := ioutil.ReadFile("./db.json")

	if err != nil {
		log.Fatal(err)
	}

	fmt.Println("Successfully readed file in bytes")

	return byteValueJSON
}

func getInformationsJSON() {
	byteValueJSON := readPessoasFromArchive()

	err := json.Unmarshal(byteValueJSON, &pessoas)

	if err != nil {
		log.Fatal(err)
	}
}

func getAllEmprestimos(w http.ResponseWriter, r *http.Request) {

	err := json.NewEncoder(w).Encode(pessoas)

	if err != nil {
		fmt.Fprint(w, err)
	}

}




// func getAllPessoas(w http.ResponseWriter, r *http.Request) {

// 	err := json.NewEncoder(w).Encode(pessoas)

// 	if err != nil {
// 		fmt.Fprint(w, err)
// 	}

// }

// func buscarPessoaPorCidade(w http.ResponseWriter, r *http.Request) {

// 	partsOfURL := strings.Split(r.URL.Path, "/")

// 	dadoRecebido := partsOfURL[2]

// 	if len(partsOfURL) > 3 {
// 		w.WriteHeader(http.StatusNotFound)
// 		return
// 	}

// 	filteredPessoas := ClienteCidade{}

// 	for _, cidade := range pessoas {
// 		if dadoRecebido == cidade.Endereco.Cidade {
// 			filteredPessoas.Cidade = cidade.Endereco.Cidade
// 			filteredPessoas.UF = cidade.Endereco.UF
// 			cliente := ClientePessoa{}
// 			cliente.Id = cidade.Id
// 			cliente.Nome = cidade.PrimeiroNome + " " + cidade.Sobrenome
// 			filteredPessoas.ClientePessoa = append(filteredPessoas.ClientePessoa, cliente)
// 		}
// 	}

// 	err := json.NewEncoder(w).Encode(filteredPessoas)

// 	if err != nil {
// 		log.Fatal(err)
// 	}
// }
