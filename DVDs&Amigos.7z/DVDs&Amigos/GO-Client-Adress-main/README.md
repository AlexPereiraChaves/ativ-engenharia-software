# GO-Client-Adress

## Para rodar o projeto:

- go run main.go

### Rodará na porta 8081
